---
name: image-generator
description: Use when the user wants to generate an image, create a picture, make an illustration, design a cover, or do image-to-image editing. Triggers include requests to "生成图片", "做图", "画图", "生图", "做封面", "做插图", "赛博朋克架构图", "赛博朋克", or any image generation task.
---

# Image Generator

AI 图片生成工具，支持文本生图（Text-to-Image）和图生图（Image-to-Image）。

## Command

```bash
python C:\Users\lvyazhou\.product-lobster\skills\image-generator\generate_images.py -p "PROMPT" [OPTIONS]
```

## Parameters

| Flag | Description | Default |
|------|-------------|---------|
| `-p` / `--prompt` | 图片描述提示词（必填） | — |
| `-i` / `--image` | 参考图片路径或URL（图生图，可多次指定） | — |
| `-m` / `--mask` | 蒙版图片（局部重绘） | — |
| `-s` / `--size` | 图片尺寸（**必须是 16 的倍数**） | `1024x1024` |
| `-n` | 生成数量 | `1` |
| `-q` / `--quality` | 质量: low, medium, high, auto | API 默认 |
| `--style` | 风格: natural, vivid | — |
| `-o` / `--output` | 输出文件名 | `generated_时间戳.png` |
| `-d` / `--dir` | 输出目录 | 当前目录下 `generated_images/` |
| `--model` | 模型 | `openai/gpt-image-2` |

## Critical Rules

### 1. 尺寸必须是 16 的倍数
**不要用** `1500x600`，**要用** `1536x608`。否则 API 会报错。

### 2. 建议显式传 -q medium
API 代理有个 bug：不传 quality 参数时可能注入无效的 `standard` 值导致 400 错误。建议每次都带上 `-q medium`。

## Common Sizes

| 用途 | 尺寸 | 比例 |
|------|------|------|
| 正方形（头像/图标） | `1024x1024` | 1:1 |
| Twitter/X 封面 | `1536x608` | ~5:2 |
| 宽屏横图 | `1792x1024` | 16:9 |
| 竖图/海报/手机壁纸 | `1024x1792` | 9:16 |

## Prompt Writing Tips

好的提示词通常包含：
- **主体与角色**：描述画面中的主要对象
- **视觉对比/冲突**：增加画面张力
- **布局方向**：如「左侧留白」「居中构图」
- **色彩方案**：如「深蓝与金色色调」「莫兰迪色系」
- **光影与美学**：如「电影感光影」「扁平插画风格」
- **留白指示**：如果需要后期加文字，注明「reserve clean negative space for text overlay」

### Chinese Text Warning
AI 生成的中文文字排版不稳定，建议：
1. **推荐**：生成干净背景 + 留白区域，后期在 Canva/Figma 加文字
2. **直接出文字**：在 prompt 中包含文字内容，但需仔细检查输出

## Preset Templates

### 🎖️ 军事作战指挥海报（Military Command Poster）

适合：团队培训海报、业务流程海报、战略方向海报、多步骤SOP图解

**风格特征：**
- 深海军蓝底色 + 战术全息网格线 + 蓝色霓虹辉光
- 军事指挥中心/战术简报美学
- 内容分块以 "PHASE" 作战阶段呈现
- 每个阶段用不同强调色（青色、绿色、橙色、红/粉色）
- 军事图标（雷达、档案、闪电、盾牌等）
- 底部金属质感 slogan 横条
- 竖版 1024x1792

**Prompt 模板：**
```
Dark navy blue background with tactical holographic grid lines and subtle blue neon glow effects. Military command center aesthetic. Title at top in large bold white text: "[标题]". Content organized as 4 phases:

PHASE 1 "[阶段1名称]" with cyan accent color and [图标] icon, bullet points: [要点...]
PHASE 2 "[阶段2名称]" with green accent color and [图标] icon, bullet points: [要点...]
PHASE 3 "[阶段3名称]" with orange accent color and [图标] icon, bullet points: [要点...]
PHASE 4 "[阶段4名称]" with red/pink accent color and [图标] icon, bullet points: [要点...]

Bottom gold metallic bar with slogan: "[slogan]"

Style: futuristic military tactical briefing, holographic UI elements, dark tech aesthetic, vertical poster layout.
```

**使用示例：**
```bash
python C:\Users\lvyazhou\.product-lobster\skills\image-generator\generate_images.py \
  -p "Dark navy blue background with tactical holographic grid lines and subtle blue neon glow effects. Military command center aesthetic. Title at top in large bold white text: 'Customer Ops Fundamentals - Four Core Actions'. Content organized as 4 phases: PHASE 1 'Organization Recon' with cyan accent and radar icon, bullets: pull org chart, map decision chain, build account ledger. PHASE 2 'Asset & Biz Intel' with green accent and dossier icon, bullets: inventory systems, track contracts, identify blind spots. PHASE 3 'Response & Comms' with orange accent and lightning bolt icon, bullets: 1-hour SLA, dedicated channel, weekly sync. PHASE 4 'Relationship Maintenance' with red/pink accent and shield icon, bullets: key person profiles, milestone outreach, closed-loop tracking. Bottom gold metallic bar: 'Know the Terrain · Standard Ops · Closed Loop · Sustained Care'. Style: futuristic military tactical briefing, holographic UI elements, dark tech aesthetic, vertical poster layout." \
  -s 1024x1792 -q medium -o military_poster.png
```

---

### 📊 运营流程图 / SOP流程图（Operations Flowchart）

适合：运营SOP、问题处理流程、客户服务流程、业务闭环流程、多角色协作流程

**风格特征：**
- 白色/浅灰干净背景，商务专业感
- 顶部大标题（深蓝色粗体），副标题说明适用范围
- 流程用编号圆圈（①②③…）串联，箭头连接各环节
- 每个环节用圆角矩形卡片，内含图标 + 要点列表
- 关键决策点用菱形（是/否分支）
- 配色系统：深蓝（标题/主流程）、橙色（警告/投诉）、绿色（解决/完成）、红色（升级/紧急）
- 底部分区展示补充信息（响应标准表格、分类说明、升级路径、角色说明、闭环步骤等）
- 整体布局从左到右为主流程，下方为支撑信息模块
- 横版宽幅 1792x1024 或更宽

**Prompt 模板：**
```
Clean white background, professional business operations flowchart. Title at top in large bold dark blue text: "[流程名称]". Subtitle: "[副标题说明]".

Main flow from left to right with numbered circle steps:
Step 1 "[环节名称]" with icon, items: [要点...]
Step 2 "[环节名称]" with icon, items: [要点...]
Step 3 "[环节名称]" with classification cards in different colors: [分类1] in blue, [分类2] in orange, [分类3] in red dashed border
Step 4 Diamond decision node: "[判断条件]" with Yes/No branches
Step 5 "[是-分支环节]" in green
Step 6 "[否-分支环节]" in orange
...continue numbering...

Bottom section divided into columns:
Column 1: "[标题]" table with rows: [内容...]
Column 2: "[标题]" with categorized items and icons
Column 3: "[标题]" with escalation paths and contact info
Bottom bar: "[角色说明]" and "[闭环管理步骤]"

Footer slogan: "[目标/口号]"

Style: clean professional infographic, flat design icons, rounded rectangle cards, numbered circle markers, arrow connectors, color-coded categories (blue=primary, green=resolved, orange=warning, red=escalation), Chinese business document aesthetic, horizontal wide layout.
```

**使用示例：**
```bash
python C:\Users\lvyazhou\.product-lobster\skills\image-generator\generate_images.py \
  -p "Clean white background, professional business operations flowchart. Title at top in large bold dark blue text: '运营问题解决流程'. Subtitle: '客户、联运商、销售及领导问题统一响应与闭环管理流程'. Main flow from left to right with numbered circle steps: Step 1 '问题接收' with phone/email/ticket icons, items: 电话, 工单, 邮件, 推推群. Step 2 '问题来源分类' with person icons: 客户, 联运商, 销售, 领导. Step 3 '问题分类识别' with three category cards: '产品类问题' in blue (安全云终端, EPP, XDR等), '运营类问题' in orange (数据接入, 工单, 报告等), '投诉类问题' in red dashed border (响应不及时, 未监测到风险等). Step 4 Diamond decision: '是否可自行解决?' with Yes/No. Step 5 '自行解决' in green (FAQ手册, 远程支持, 知识共享). Step 6 '升级产线/研发' in orange. Bottom section: response time table, problem classification details, escalation paths with contacts, role descriptions, 4-step closed loop (问题记录→过程跟踪→结果反馈→FAQ沉淀). Footer: '目标：快速响应、有效解决、持续优化，提升客户满意度与运营效率'. Style: clean professional infographic, flat design, rounded cards, numbered circles, arrow connectors, color-coded, Chinese business aesthetic, horizontal wide layout." \
  -s 1792x1024 -q medium -o ops_flowchart.png
```

---

### 🔷 赛博朋克架构图（Cyberpunk Architecture Diagram）

适合：系统架构图、技术方案图、安全运营中心架构、多智能体架构、平台生态图、技术栈全景图

**⚠️ 强制规则：整个提示词必须用中文撰写，所有模块名、层级名、标签文字一律用中文。不要出现英文描述。唯一例外是专有技术术语缩写（如 OSINT、DNS、PDF 等）。**

**风格特征：**
- 深海军蓝色背景 + 六边形网格纹理 + 青色霓虹辉光效果
- 从上到下分层布局，层级清晰
- 每个模块用圆角矩形，带霓虹色边框（青色、绿色、红色、紫色分区）
- 模块间用发光连接线串联
- 配有小图标描述（锁、盾牌、数据库、雷达等）
- 右侧栏或底部可加补充面板
- 横版宽幅 1792x1024

**Prompt 模板：**
```
深海军蓝色背景，六边形网格纹理，青色霓虹辉光效果。赛博朋克安全运营中心美学风格。一张[主题描述]架构图。从上到下分为[N]个水平层级：

第一层（顶部）：[层名] - [具体模块描述，每个节点用圆角矩形加霓虹边框（分别为青色、绿色、红色、紫色）]。

第二层：[层名] - [模块列表，包含风险评级标识（高危红色、中危橙色、低危黄色）等细节]。

第三层：[层名] - [模块列表，配有小图标（锁、盾牌、数据库等）]。

第四层：[层名] - [模块列表，含端口号等技术细节]。

第五层（底部）：[层名] - [模块列表]。

右侧栏：[侧边面板名称]，包含[内容]。
底部：[补充可视化元素]。

风格：未来全息UI、霓虹发光边框、暗黑科技美学、高信息密度信息图、专业网络安全仪表盘设计。所有文字使用中文标签。
```

**Prompt 写作要点：**
1. **全中文提示词**：整个 prompt 必须用中文写，所有模块名、层级名、标签一律中文，仅技术缩写（DNS、PDF、API 等）可保留英文
2. **背景三件套**：深海军蓝色背景 + 六边形网格纹理 + 青色霓虹辉光效果（固定不变）
3. **分层布局**：明确"从上到下分为N个水平层级"，每层标注（顶部）/（底部）
4. **霓虹配色**：每个区域/节点指定具体霓虹色（青色、绿色、红色、紫色）
5. **细节堆料**：具体到端口号、文件格式、图标类型，信息密度越高越好
6. **侧边栏/底部**：加右侧面板或底部补充元素，丰富画面
7. **风格收尾**：固定用"未来全息UI、霓虹发光边框、暗黑科技美学、高信息密度信息图"
8. **末尾强调**：prompt 最后必须加"所有文字使用中文标签"这句话

**使用示例（验证过，效果很好）：**
```bash
python C:\Users\lvyazhou\.product-lobster\skills\image-generator\generate_images.py \
  -p "深海军蓝色背景，六边形网格纹理，青色霓虹辉光效果。赛博朋克安全运营中心美学风格。一张多智能体协作的自动化渗透测试系统架构图。从上到下分为六个水平层级：第一层（顶部）：控制与编排层 - 中央主控Agent节点连接四个卫星Agent节点（OSINT Agent、Recon Agent、Exploit Agent、Report Agent），每个节点用圆角矩形加霓虹边框（分别为青色、绿色、红色、紫色）。第二层：成果整理层 - 包含攻击面全景图、风险总览、漏洞详情、风险评级标识（高危红色、中危橙色、低危黄色）、修复建议、报告导出（PDF/JSON/CSV）、工单对接模块。第三层：漏洞验证层 - 包含Web漏洞扫描验证、弱口令与凭证检测、凭证泄露与拖库检测、配置与安全基线检测模块，配有小图标（锁、盾牌、数据库）。第四层：侦察与指纹层 - 包含域名与子域名枚举、端口与服务探测（22/80/443）、Web指纹识别、敏感路径与接口枚举、云服务指纹识别、攻击面矩阵输出模块。第五层（底部）：互联网资产发现层 - 包含被动DNS、证书透明度、搜索引擎与爬虫、WHOIS注册信息、威胁情报源、GitHub代码仓库扫描模块。右侧栏：安全护栏与合规控制面板，包含范围控制和审计日志。底部：资产风险拓扑示例，展示域名节点与风险指标连接。风格：未来全息UI、霓虹发光边框、暗黑科技美学、高信息密度信息图、专业网络安全仪表盘设计。所有文字使用中文标签。" \
  -s 1792x1024 -q medium -o cyberpunk_architecture.png
```

---

## Examples

```bash
# 基础文本生图
python C:\Users\lvyazhou\.product-lobster\skills\image-generator\generate_images.py \
  -p "A cute orange tabby cat sitting on a windowsill, warm sunlight, cozy atmosphere" \
  -q medium

# Twitter/X 封面
python C:\Users\lvyazhou\.product-lobster\skills\image-generator\generate_images.py \
  -p "Cinematic wide illustration: futuristic cityscape with neon lights reflecting on wet streets, cyberpunk aesthetic, deep blue and magenta tones, clean space on the left for text" \
  -s 1536x608 -q medium -o twitter_cover.png

# 图生图（修改已有图片）
python C:\Users\lvyazhou\.product-lobster\skills\image-generator\generate_images.py \
  -p "Transform this into a watercolor painting style, keep the composition" \
  -i /path/to/source.png -q medium

# 竖版海报
python C:\Users\lvyazhou\.product-lobster\skills\image-generator\generate_images.py \
  -p "Minimalist poster design: a single tree on a hill, golden hour, soft gradients" \
  -s 1024x1792 -q medium -o poster.png

# 指定输出到项目目录
python C:\Users\lvyazhou\.product-lobster\skills\image-generator\generate_images.py \
  -p "App icon: a brain with circuit patterns, flat design, gradient blue to purple" \
  -s 1024x1024 -q medium -d /path/to/project/assets -o app_icon.png
```
